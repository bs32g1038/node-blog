import React, { Component } from 'react';
import { Layout, Breadcrumb, Button, Table, Popconfirm, Modal } from 'antd';
const { Content } = Layout;
import GuestbookReplyForm from './GuestbookReplyForm';
import { parseTime } from '../libs/parse-time';
const { Column } = Table;
import { fetchGuestbooks, updateReply, deleteGuestbook } from '../redux/guestbook';

class GuestbookList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedRowKeys: [],
      visible: false,
      guestbook: {},
      loading: false
    }
  }
  showModal = (guestbook) => {
    this.setState({ guestbook: guestbook, visible: true })
  }
  onOk = () => {
    const { dispatch } = this.props;
    this.form.validateFields((err, data) => {
      if (!err) {
        dispatch(updateReply(this.state.guestbook._id, data.reply_content)).then(() => {
          this.setState({ visible: false })
        })
      }
    });
  }
  onCancel = () => {
    this.setState({ visible: false })
  }
  saveFormRef = (form) => {
    this.form = form;
  }
  deleteGuestbook = (id) => {
    const { dispatch } = this.props;
    dispatch(deleteGuestbook(id))
  }
  onChange = (pagination) => {
    this.fetchData({
      per_page: pagination.pageSize,
      page: pagination.current
    })
  }
  onSelectChange = (selectedRowKeys) => {
    this.setState({ selectedRowKeys });
  }
  fetchData = ({ page, per_page }) => {
    const { dispatch } = this.props;
    this.setState({ loading: true })
    dispatch(fetchGuestbooks({ page, per_page })).then((data) => {
      this.setState({ loading: false })
    }).catch(function (err) {
    })
  }
  componentWillMount() {
    this.fetchData({})
  }
  render() {
    const { items, totalCount } = this.props.guestbooks;
    const pagination = { total: totalCount };
    const rowSelection = {
      selectedRowKeys: this.state.selectedRowKeys,
      onChange: this.onSelectChange,
    };
    return (
      <Content>
        <Breadcrumb>
          <Breadcrumb.Item>首页</Breadcrumb.Item>
          <Breadcrumb.Item>留言管理</Breadcrumb.Item>
          <Breadcrumb.Item>留言列表</Breadcrumb.Item>
        </Breadcrumb>
        <div className='panel'>
          <Button type="danger"><i className="fa fa-trash-o fa-fw"></i>&nbsp;&nbsp;批量删除</Button>
        </div>
        <Table
          dataSource={items}
          rowKey={(record) => (record._id)}
          pagination={pagination}
          rowSelection={rowSelection}
          onChange={this.onChange}
          loading={this.state.loading}
        >
          <Column
            title='昵称'
            dataIndex='nick_name'
          />
          <Column
            title='创建时间'
            dataIndex='create_at'
            render={(text, record) => (parseTime(text))}
          />
          <Column
            title='内容'
            dataIndex='content'
            width={250}
          />
          <Column
            title='邮箱'
            dataIndex='email'
          />
          <Column
            title='管理员回复的内容'
            dataIndex='reply_content'
            width={250}
          />
          <Column
            title='操作'
            key='action'
            width={76}
            render={(text, record, index) => (
              <span>
                <a href="javascript:;" onClick={() => { this.showModal(record) }}><i className="fa fa-reply fa-fw"></i>回复</a>
                <br />
                <Popconfirm title="确定要删除？" onConfirm={() => this.deleteGuestbook(record._id)} onCancel={() => { }} okText="Yes" cancelText="No">
                  <a href="javascript:;"><i className="fa fa-trash-o fa-fw"></i>删除</a>
                </Popconfirm>
              </span>
            )}
          />
        </Table>
        {/*<GuestbookListItem
                    rowSelection={rowSelection}
                    columns={this.state.columns}
                    dataSource={items}
                    loading={loading}
                    pagination={pagination}
                    onChange={this.onGuestbookListChange}
                    handlePass={this.handleGuestbookPass}
                    deleteGuestbook={this.deleteGuestbook}
                    replyGuestbook={this.showModal}
                >
                </GuestbookListItem>*/}
        <Modal
          title="回复留言"
          okText="提交"
          visible={this.state.visible}
          onCancel={this.onCancel}
          onOk={this.onOk}
        >
          <GuestbookReplyForm
            guestbook={this.state.guestbook}
            ref={this.saveFormRef}
          ></GuestbookReplyForm>
        </Modal>
      </Content>
    );
  }
}

export default GuestbookList;