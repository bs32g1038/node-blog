import React, { Component } from 'react';
import { Modal, Form, Input } from 'antd';
const FormItem = Form.Item;
class LinkEditForm extends Component {
  render() {
    let { form, link } = this.props;
    const { getFieldDecorator } = form;
    return (
      <Form>
        <FormItem label="名称" labelCol={{ span: 4 }} wrapperCol={{ span: 10 }}>
          {getFieldDecorator('name', {
            rules: [{ required: true, message: '名称不能为空！', }],
            initialValue: link.name
          })(
            <Input type="text" />
            )}
        </FormItem>
        <FormItem label="url" labelCol={{ span: 4 }} wrapperCol={{ span: 10 }}>
          {getFieldDecorator('url', {
            rules: [{ required: true, message: 'url不能为空！', }],
            initialValue: link.url
          })(
            <Input type="text" />
            )}
        </FormItem>
      </Form>
    );
  }
}

export default Form.create()(LinkEditForm)