import React, { Component } from 'react';
import { Layout, Breadcrumb, Button, Form, message, Modal, Table, Popconfirm } from 'antd';
const { Content } = Layout;
import LinkEditForm from './LinkEditForm';
import { fetchLinks, saveLink, deleteLink } from '../redux/link';
const {Column} = Table;

class LinkList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedRowKeys: [],
      visible: false,
      link: {}
    }
  }
  showModal = (link) => {
    this.setState({ link: link, visible: true })
  }
  onOk = () => {
    const { dispatch } = this.props;
    this.form.validateFields((err, data) => {
      if (!err) {
        dispatch(saveLink(this.state.link._id, data)).then(() => {
          this.form.resetFields()
          this.setState({ visible: false });
        })
      }
    });
  }
  onCancel = () => {
    this.setState({ visible: false })
  }
  saveFormRef = (form) => {
    this.form = form;
  }
  deleteLink = (id) => {
    const { dispatch } = this.props;
    dispatch(deleteLink(id))
  }
  onSelectChange = (selectedRowKeys) => {
    this.setState({ selectedRowKeys });
  }
  componentWillMount() {
    const { dispatch } = this.props;
    dispatch(fetchLinks());
  }
  render() {
    const { items } = this.props.links;
    const rowSelection = {
      selectedRowKeys: this.state.selectedRowKeys,
      onChange: this.onSelectChange,
    };
    return (
      <Content>
        <Breadcrumb>
          <Breadcrumb.Item>首页</Breadcrumb.Item>
          <Breadcrumb.Item>文章管理</Breadcrumb.Item>
          <Breadcrumb.Item>评论列表</Breadcrumb.Item>
        </Breadcrumb>
        <div className='panel'>
          <Button type="primary" onClick={() => (this.showModal({}))}><i className="fa fa-plus-square fa-fw"></i>&nbsp;&nbsp;添加链接</Button>
          <Button type="danger"><i className="fa fa-trash-o fa-fw"></i>&nbsp;&nbsp;批量删除</Button>
        </div>
        <Table
          dataSource={items}
          rowKey={(record) => (record._id)}
          pagination={false}
          rowSelection={rowSelection}
        >
          <Column
            title='名称'
            dataIndex='name'
          />
          <Column
            title='url'
            dataIndex='url'
          />
          <Column
            title='操作'
            key='action'
            render={(text, record, index) => (
              <span>
                <a href="javascript:;" onClick={() => { this.showModal(record) }}><i className="fa fa-edit fa-fw"></i>编辑</a>
                <span className="ant-divider" />
                <Popconfirm title="确定要删除？" onConfirm={() => this.deleteLink(record._id)} onCancel={() => { }} okText="Yes" cancelText="No">
                  <a href="javascript:;"><i className="fa fa-trash-o fa-fw"></i>删除</a>
                </Popconfirm>
              </span>
            )}
          />
        </Table>
        <Modal
          title={this.state.link._id ? "修改链接" : '添加链接'}
          okText="提交"
          visible={this.state.visible}
          onCancel={this.onCancel}
          onOk={this.onOk}
        >
          <LinkEditForm
            ref={this.saveFormRef}
            link={this.state.link}
          ></LinkEditForm>
        </Modal>
      </Content>
    );
  }

}

export default LinkList;