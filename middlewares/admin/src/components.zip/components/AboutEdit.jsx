import React, { Component } from 'react';
import { Form, Input, Button, Layout, Breadcrumb, notification } from 'antd';
const FormItem = Form.Item;
const { Content } = Layout;
import Editor from './Editor';
import { fetchAbout, updateAbout } from '../redux/about';

class AboutForm extends Component {
    constructor(props) {
        super(props)
    }
    handleSubmit = (e) => {
        e.preventDefault();
        const { dispatch } = this.props;
        this.props.form.validateFields((err, data) => {
            if (!err) {
                dispatch(updateAbout(data))
            }
        });
    }
    componentWillMount() {
        const { dispatch } = this.props;
        dispatch(fetchAbout());
    }
    render() {
        const { getFieldDecorator } = this.props.form;
        const { about } = this.props;
        return (
            <Content>
                <Breadcrumb>
                    <Breadcrumb.Item>首页</Breadcrumb.Item>
                    <Breadcrumb.Item>博客关于管理</Breadcrumb.Item>
                    <Breadcrumb.Item>关于信息编辑</Breadcrumb.Item>
                </Breadcrumb>
                <Form onSubmit={this.handleSubmit} style={{ marginTop: '20px' }}>
                    <FormItem label="标题" labelCol={{ span: 4 }} wrapperCol={{ span: 10 }}>
                        {getFieldDecorator('title', {
                            rules: [{ required: true, message: '标题不能为空！', }],
                            initialValue: about.title
                        })(
                            <Input type="text" />
                            )}
                    </FormItem>
                    <FormItem label="内容" labelCol={{ span: 4 }} wrapperCol={{ span: 18 }}>
                        {getFieldDecorator('content', {
                            rules: [
                                { required: true, message: '请填写内容!' },
                            ],
                            initialValue: about.content
                        })(
                            <Editor />
                            )}
                    </FormItem>
                    <FormItem label="操作" labelCol={{ span: 4 }} wrapperCol={{ span: 4 }}>
                        <Button type="primary" htmlType="submit" size="large">提交</Button>
                    </FormItem>
                </Form>
            </Content>
        );
    }
};

export default Form.create()(AboutForm)