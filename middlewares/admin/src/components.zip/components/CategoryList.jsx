import React, { Component } from 'react';
import { Layout, Breadcrumb, Button, Table, Popconfirm, Modal } from 'antd';
const { Content } = Layout;
import CategoryEditForm from './CategoryEditForm';
import { parseTime } from '../libs/parse-time';
const { Column } = Table;

import { saveCategory, deleteCategory } from '../redux/category';

class CategoryList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedRowKeys: [],
            visible: false,
            category: {}
        }
    }
    showModal = (category) => {
        this.setState({ category: category || {}, visible: true })
    }
    onOk = () => {
        const { dispatch } = this.props;
        this.form.validateFields((err, data) => {
            console.log(data)
            if (!err) {
                dispatch(saveCategory(this.state.category._id, data)).then(() => {
                    this.setState({ visible: false })
                });
            }
        });
    }
    onCancel = () => {
        this.setState({ visible: false })
    }
    saveFormRef = (form) => {
        this.form = form;
    }
    deleteCategory = (id) => {
        const { dispatch } = this.props;
        dispatch(deleteCategory(id))
    }
    onSelectChange = (selectedRowKeys) => {
        this.setState({ selectedRowKeys });
    }
    render() {
        const { items } = this.props.categories;
        const rowSelection = {
            selectedRowKeys: this.state.selectedRowKeys,
            onChange: this.onSelectChange,
        };
        return (
            <Content >
                <Breadcrumb>
                    <Breadcrumb.Item>首页</Breadcrumb.Item>
                    <Breadcrumb.Item>文章管理</Breadcrumb.Item>
                    <Breadcrumb.Item>分类列表</Breadcrumb.Item>
                </Breadcrumb>
                <div className='panel'>
                    <Button type="primary" onClick={() => (this.showModal())}><i className="fa fa-plus-square fa-fw"></i>&nbsp;&nbsp;添加分类</Button>
                    <Modal
                        visible={this.state.visible}
                        title={this.state.category._id ? "编辑分类" : "添加分类"}
                        okText="提交"
                        onCancel={this.onCancel}
                        onOk={this.onOk}>
                        <CategoryEditForm
                            ref={this.saveFormRef}
                            category={this.state.category}
                        ></CategoryEditForm>
                    </Modal>
                    <Button type="danger"><i className="fa fa-trash-o fa-fw"></i>&nbsp;&nbsp;批量删除</Button>
                </div>
                <Table
                    dataSource={items}
                    rowKey={(record) => (record._id)}
                    pagination={false}
                    rowSelection={rowSelection}
                >
                    <Column
                        title='名称'
                        dataIndex='name'
                        render={text => text}
                    />
                    <Column
                        title='别称'
                        dataIndex='alias'
                    />
                    <Column
                        title='权重'
                        dataIndex='order'
                    />
                    <Column
                        title='创建时间'
                        dataIndex='create_at'
                        render={(text, record) => (parseTime(text))}
                    />
                    <Column
                        title='文章数量'
                        dataIndex='article_count'
                    />
                    <Column
                        title='操作'
                        key='action'
                        render={(text, record) => (
                            <span>
                                <a onClick={() => this.showModal(record)}><i className="fa fa-edit fa-fw"></i>修改</a>
                                <span className="ant-divider" />
                                <Popconfirm title="确定要删除？" onConfirm={() => this.deleteCategory(record._id)} onCancel={() => { }} okText="Yes" cancelText="No">
                                    <a href="#"><i className="fa fa-trash-o fa-fw"></i>删除</a>
                                </Popconfirm>
                            </span>
                        )}
                    />
                </Table>
            </Content >
        );
    }
}

export default CategoryList