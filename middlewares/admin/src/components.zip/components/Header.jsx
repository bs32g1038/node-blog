/*
 * @Author: bs32g1038@163.com
 * @Date: 2017-02-07 16:52:27
 * @Last Modified by: bs32g1038@163.com
 * @Last Modified time: 2017-06-12 17:06:13
 */

import { Layout } from 'antd';
import React from 'react';
import axios from 'axios';
const { Header } = Layout;

class header extends React.Component {
  render() {
    let { user } = this.props;
    console.log(user, this.props)
    return (
      <Header className="header">
        <a href="/" className="logo">
          <img src="./images/logo.png" alt="博客" />博客后台管理--谁
                </a>
        <div className="fr navbar-nav">
          <ul>
            <li className="user-menu">
              <a href="/admin/articles">
                <img src="./images/avatar/256.jpg" className="user-image" alt="" />
                <span className="hidden-xs">{user.nick_name}-博主</span>
              </a>
            </li>
            <li>
              <a onClick={() => (this.handleSignOut())}><i className="fa fa-power-off fa-fw" ></i>注销</a>
            </li>
          </ul>
        </div>
      </Header>
    );
  }

  handleSignOut() {
    let base_url = '/api/admin/sessions/user';
    axios.delete(base_url).then(function (res) {
      window.location = '/admin/login';
    })
  }

}

export default header