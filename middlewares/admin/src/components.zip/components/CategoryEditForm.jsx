import React, { Component } from 'react';
import { Modal, Form, Input, Alert } from 'antd';
const FormItem = Form.Item;

class CategoryEditForm extends Component {
    render() {
        let { form, category } = this.props;
        category = category || {}
        const { getFieldDecorator } = form;
        return (
            <Form>
                <Alert message="注意：分类的名称和别称必须唯一，不能重复！" type="warning" closable />
                <FormItem label="名称" labelCol={{ span: 6 }} wrapperCol={{ span: 10 }}>
                    {getFieldDecorator('name', {
                        rules: [{ required: true, message: '请输入分类名称!' }],
                        initialValue: category.name
                    })(
                        <Input />
                        )}
                </FormItem>
                <FormItem label="别称" labelCol={{ span: 6 }} wrapperCol={{ span: 10 }} >
                    {getFieldDecorator('alias', {
                        rules: [{ required: true, message: '请输入分类别称!' }],
                        initialValue: category.alias,

                    })(
                        <Input />
                        )}
                </FormItem>
            </Form>
        );
    }
}
export default Form.create()(CategoryEditForm);