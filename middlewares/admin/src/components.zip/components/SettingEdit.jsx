import React, { Component } from 'react';
import { Form, Input, Button, Layout, Breadcrumb, notification } from 'antd';
const FormItem = Form.Item;
const { Content } = Layout;
import { fetchSetting, updateSetting } from '../redux/setting';

class BaseSettingForm extends Component {
    constructor(props) {
        super(props)
    }
    handleSubmit = (e) => {
        e.preventDefault();
        const { dispatch } = this.props;
        this.props.form.validateFields((err, data) => {
            if (!err) {
                dispatch(updateSetting(data));
            }
        });
    }
    componentWillMount() {
        const { dispatch } = this.props;
        dispatch(fetchSetting());
    }
    render() {
        const { getFieldDecorator } = this.props.form;
        const { setting } = this.props;
        return (
            <Content>
                <Breadcrumb>
                    <Breadcrumb.Item>首页</Breadcrumb.Item>
                    <Breadcrumb.Item>博客配置管理</Breadcrumb.Item>
                    <Breadcrumb.Item>基础配置信息编辑</Breadcrumb.Item>
                </Breadcrumb>
                <Form onSubmit={this.handleSubmit} style={{ marginTop: '20px' }}>
                    <FormItem label="网站名称" labelCol={{ span: 4 }} wrapperCol={{ span: 10 }}>
                        {getFieldDecorator('site_name', {
                            rules: [{ required: true, message: '网站名称不能为空！', }],
                            initialValue: setting.site_name
                        })(
                            <Input type="text" />
                            )}
                    </FormItem>
                    <FormItem label="网站描述" labelCol={{ span: 4 }} wrapperCol={{ span: 10 }}>
                        {getFieldDecorator('site_description', {
                            rules: [
                                { required: true, message: '请填写内容!' },
                            ],
                            initialValue: setting.site_description
                        })(
                            <Input type="text" />
                            )}
                    </FormItem>
                    <FormItem label="网站关键词" labelCol={{ span: 4 }} wrapperCol={{ span: 10 }}>
                        {getFieldDecorator('site_keywords', {
                            rules: [
                                { required: true, message: '请填写关键词!' },
                            ],
                            initialValue: setting.site_keywords
                        })(
                            <Input type="text" />
                            )}
                    </FormItem>
                    <FormItem label="网站Logo" labelCol={{ span: 4 }} wrapperCol={{ span: 10 }}>
                        {getFieldDecorator('site_logo', {
                            rules: [
                                { required: true, message: '请填写Logo!' },
                            ],
                            initialValue: setting.site_logo
                        })(
                            <Input type="text" />
                            )}
                    </FormItem>
                    <FormItem label="网站备案icp" labelCol={{ span: 4 }} wrapperCol={{ span: 10 }}>
                        {getFieldDecorator('site_icp', {
                            rules: [
                                { required: true, message: '请填写网站备案icp!' },
                            ],
                            initialValue: setting.site_icp
                        })(
                            <Input type="text" />
                            )}
                    </FormItem>
                    <FormItem label="网站域名" labelCol={{ span: 4 }} wrapperCol={{ span: 10 }}>
                        {getFieldDecorator('site_domain', {
                            rules: [
                                { required: true, message: '请填写网站域名!' },
                            ],
                            initialValue: setting.site_domain
                        })(
                            <Input type="text" />
                            )}
                    </FormItem>
                    <FormItem label="网页头部代码信息" labelCol={{ span: 4 }} wrapperCol={{ span: 10 }}>
                        {getFieldDecorator('site_header_code', {
                            rules: [
                                { required: true, message: '请填写网页头部代码信息!' },
                            ],
                            initialValue: setting.site_header_code
                        })(
                            <Input type="textarea" autosize={{ minRows: 6, maxRows: 8 }} />
                            )}
                    </FormItem>
                    <FormItem label="操作" labelCol={{ span: 4 }} wrapperCol={{ span: 4 }}>
                        <Button type="primary" htmlType="submit" size="large">提交</Button>
                    </FormItem>
                </Form>
            </Content>
        );
    }
};

export default Form.create()(BaseSettingForm)